﻿using System;

namespace CarManufacturer
{
	public class Car
	{
		private string make;
        private string made;
        private int year;

        public string Make
        {
            get { return make; }
            set { this.make = value; }
        }
        public string Made
        {
            get { return made; }
            set { this.made = value; }
        }
        public int Year
        {
            get { return year; }
            set { this.year = value; }
        }
    }
}

