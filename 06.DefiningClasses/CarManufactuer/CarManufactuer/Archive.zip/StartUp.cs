﻿using System;
namespace CarManufactuer
{
	public class StartUp
	{
		public StartUp()
		{
			
		}
	}
}

